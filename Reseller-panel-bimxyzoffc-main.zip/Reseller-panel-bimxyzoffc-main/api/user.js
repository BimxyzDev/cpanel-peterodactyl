export const users = [
  {
    "username": "Admin",
    "password": "Admin089"
  },
  {
    "username": "rapzganteng",
    "password": "gantengnjir"
  },
  {
    "username": "Gondes089",
    "password": "089630"
  },
  {
    "username": "xccv",
    "password": "xccv333"
  },
  {
    "username": "Akmal",
    "password": "17"
  },
  {
    "username": "Starla123",
    "password": "Starla123"
  },
  {
    "username": "Ryu",
    "password": "Ryu08"
  },
  {
    "username": "hayabusa",
    "password": "store"
  },
  {
    "username": "Yann321",
    "password": "Qwerty1"
  },
  {
    "username": "LemmFdx",
    "password": "Lemmfskapnl"
  },
  {
    "username": "valak",
    "password": "therealm135"
  },
  {
    "username": "Zarr",
    "password": "Zarr888"
  },
  {
    "username": "dikzajalah",
    "password": "dikzajalah"
  },
  {
    "username": "Zexa",
    "password": "enakamba123"
  },
  {
    "username": "pias",
    "password": "kontol112"
  },
  {
    "username": "auuu",
    "password": "hiag"
  },
  {
    "username": "rdillnh",
    "password": "987654312"
  },
  {
    "username": "BOB",
    "password": "DUCK"
  },
  {
    "username": "oscarNotbound",
    "password": "oscarvx"
  }
];