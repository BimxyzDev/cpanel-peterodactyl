export const PANEL_URL = "https://peterodatcly.bimxyz.my.id";
export const API_KEY = "ptla_abj2PXPKPRX92vPiAp4Du9HLPco2EcFBJOpsd0HxVjB";
export const NODE_ID = "1";
export const NEST_ID = "5";
export const EGG_ID = "15";
export const DOCKER_IMG = "ghcr.io/parkervcp/yolks:nodejs_20";
